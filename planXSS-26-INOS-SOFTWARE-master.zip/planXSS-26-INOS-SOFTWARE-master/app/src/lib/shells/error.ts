export class ShellError extends Error {}
