import TestComponent from "./TestComponent";

export { TestComponent };
