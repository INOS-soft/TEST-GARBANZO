import boto3


def hello(event, context):
    return {"status": 200}


def hello2(event, context):
    return {"status": 200}
