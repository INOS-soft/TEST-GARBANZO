Please see the [official issue tracker], [doc/contributing.rdoc] and wiki [HowToContribute].

[official issue tracker]: https://bugs.ruby-lang.org
[doc/contributing.rdoc]: doc/contributing.rdoc
[HowToContribute]: https://bugs.ruby-lang.org/projects/ruby/wiki/HowToContribute
