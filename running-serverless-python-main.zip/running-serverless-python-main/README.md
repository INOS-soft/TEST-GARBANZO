A sample application for the Running Serverless book tutorial by Gojko Adzic rewritten in Python

For more information see: https://runningserverless.com/
