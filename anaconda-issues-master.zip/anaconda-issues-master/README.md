Please submit Anaconda issues to the [issue tracker](
https://github.com/ContinuumIO/anaconda-issues/issues) of this repository.

Note: This issue tracker is for issues with the Anaconda Python distribution,
its installers, and its packages.
For issues with the [Conda](https://conda.io/) package manager
unrelated to any specific package, please use the
[Conda issue tracker](https://github.com/conda/conda/issues).

To download Anaconda, visit the [Anaconda download page](
https://www.anaconda.com/distribution/).
