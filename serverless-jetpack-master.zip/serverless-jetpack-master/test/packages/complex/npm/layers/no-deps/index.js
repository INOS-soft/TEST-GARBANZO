"use strict";

exports.module = {
  msg: "I have no dependencies"
};
