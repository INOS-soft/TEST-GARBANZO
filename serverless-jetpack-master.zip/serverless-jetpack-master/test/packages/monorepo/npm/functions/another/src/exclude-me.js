"use strict";

module.exports = "I should be excluded by serverless.yml patterns";
