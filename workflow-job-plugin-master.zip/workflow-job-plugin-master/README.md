# Pipeline: Job Plugin

[![Jenkins Plugin](https://img.shields.io/jenkins/plugin/v/workflow-job)](https://plugins.jenkins.io/workflow-job)
[![Changelog](https://img.shields.io/github/v/tag/jenkinsci/workflow-job-plugin?label=changelog)](https://github.com/jenkinsci/workflow-job-plugin/blob/master/CHANGELOG.md)
[![Jenkins Plugin Installs](https://img.shields.io/jenkins/plugin/i/workflow-job?color=blue)](https://plugins.jenkins.io/workflow-job)

## Introduction

A key component of the Pipeline plugin suite, this plugin provides the Jenkins job and build types for Pipeline along with a generic user interface.
