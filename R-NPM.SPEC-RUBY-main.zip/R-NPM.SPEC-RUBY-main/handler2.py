import flask

def hello(event, context):
    return {
        'status': 200,
    }
