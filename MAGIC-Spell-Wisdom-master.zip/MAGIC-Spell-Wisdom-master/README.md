# README

This app is about displaying updates:

- My Ruby Version: 3.0.0

- My rails Version: 6.1.3

- Please run `bundle install` to install dependency.

- You might need to run `rails webpacker:install` in project root if error messages such as `Webpacker can't find application.js ` shows up in terminal after running the server.

- After cloning the project, please navigating to [localhost:3000](http://localhost:3000/) to view project.
