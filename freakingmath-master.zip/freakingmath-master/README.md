Freaking Math Open Source -Libgdx
============
FREAKING MATH Open Source : is the best game for testing your intelligence, smart and clever.
FREAKING MATH will make you get mad with the simple calculation but total time to calculate is just nearly 1 seconds.
Touch "Play" to start “FREAKING MATH” now

Avaiable for test on Google play : 
https://play.google.com/store/apps/details?id=vn.pp.freakingadult


<b>HOW TO PLAY</b>
- Too simple, just do calculation but one per second.

<b>FEATURE</b>
- Compete source code.
- Addicted game.
- Clean & Clear design.
- add to share Facebook function with screen shoot.
- Compatible with mutilple platform by libgdx
 
<b>How to build<b>

On Android 
- Check out lastest source code
- Install eclipse, ADT, JDK 1.6 or later , Windows Android SDK
- Open eclipse and click: File -> Import -> Existing Projects into Workspace
- Include <a href = "https://developers.facebook.com/docs/android/">Facebook SDK</a> and  <a href="https://developers.google.com/games/services/android/quickstart#step_4_test_your_game">Game Base Utils</a> library project in Library of Freaking Math Android Project 
- Build Resource by go to FreakingMath/src/vn.pp.freakingaudult/MyTTPacker.java and run as Java Application
- Then build and run Freaking Math Android project

On IOS
- You must install Eclipse, ADT, JDK1.6 or higher, IOS Android SDK , XCode on your 
- Install RoboVM plugin for eclipse by Help/Install new Software and get Robovm at http://download.robovm.org/eclipse/ repository
- Open eclipse and click: File -> Import -> Existing Projects into Workspace
- Build Resource by go to FreakingMath/src/vn.pp.freakingaudult/MyTTPacker.java and run as Java Application
- Build and run RoboVM project by Right click the robovm project, Run As -> iOS Device App to run on a connected device, or Run As -> iOS Simulator App to run on the iOS simulator. If you run on a device, you need to provision it to be able to deploy to it! 

More information in Libgdx: 
https://github.com/libgdx/libgdx/wiki/Project-setup,-running-&-debugging
