package vn.pp.freakingadult.utils;

public class Setting {
    public static float TIME_DEFAULT = 1f;
	public static float configTime=0;
	public static int configLevel=1;
}
