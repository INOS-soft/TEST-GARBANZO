export default abstract class IBaseType {
    public abstract method1(): void;
}
