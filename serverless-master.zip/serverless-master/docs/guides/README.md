<!--
title: Serverless Framework - User Guides
menuText: User Guides
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/guides/)

<!-- DOCS-SITE-LINK:END -->

# Serverless Framework User Guides

Welcome to the Serverless Framework User Guides!

[Get started with Serverless Framework](/framework/docs/getting-started)

If you have questions, join the [chat in Slack](https://serverless.com/slack) or [post over on the forums](https://forum.serverless.com/)
