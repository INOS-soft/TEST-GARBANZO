<!--
title: Google Cloud Functions Serverless Events
menuText: Events
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/google/events/)

<!-- DOCS-SITE-LINK:END -->

# Serverless Google Cloud Functions Events

Welcome to the Serverless Google Cloud Functions Events Glossary!

Please select a section on the left to get started.

If you have questions, join the [chat in gitter](https://gitter.im/serverless/serverless) or [post over on the forums](http://forum.serverless.com/)

**Note:** Before continuing [Google Cloud system credentials](../guide/credentials.md) are required for using the CLI.
