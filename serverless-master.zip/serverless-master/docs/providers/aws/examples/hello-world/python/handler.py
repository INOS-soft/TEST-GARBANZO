def helloWorldHandler(event, context):
  message = {
    'message': 'Hello World'
  }

  return message
