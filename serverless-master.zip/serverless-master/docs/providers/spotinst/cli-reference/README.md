<!--
title: Serverless - Spotinst Functions - CLI Reference
menuText: CLI Reference
layout: Doc
menuOrder: 2
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/spotinst/cli-reference/)

<!-- DOCS-SITE-LINK:END -->

# Serverless Spotinst Functions CLI Reference

Welcome to the Serverless Spotinst Functions CLI Reference!

Please select a section on the left to get started.

**Note:** Before continuing [Spotinst Functions credentials](../guide/credentials.md) are required for using the CLI.
