<!--
title: Serverless - Spotinst Functions - Events
menuText: Events
layout: Doc
menuOrder: 3
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/spotinst/events/)

<!-- DOCS-SITE-LINK:END -->

# Serverless Spotinst Functions Events

Welcome to the Serverless Spotinst Functions Events Glossary.

Please select a section on the left to get started.

**Note:** Before continuing [Spotinst Functions credentials](../guide/credentials.md) are required for using the CLI.
