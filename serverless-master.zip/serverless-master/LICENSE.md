I am providing code and resources in this repository to you under an open source
license.  Because this is my personal repository, the license you receive to my
code and resources is from me and not my employer (Facebook).

Copyright 2017 Donne Martin

Creative Commons Attribution 4.0 International License (CC BY 4.0)

http://creativecommons.org/licenses/by/4.0/
