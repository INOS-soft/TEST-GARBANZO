//
//  NSObject_Extension.h
//  FixCode
//
//  Created by Boris Bügling on 31/10/15.
//  Copyright (c) 2015 Fastlane. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Xcode_Plugin_Template_Extension)

+ (void)pluginDidLoad:(NSBundle *)plugin;

@end
